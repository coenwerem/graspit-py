24 LEAP static grasp candidates on a YCB mustard-bottle mesh.
Keep the NPZ and JSON sidecar in one directory. Read with NumPy allow_pickle=False
or graspit_py.dataset.load_dataset. Lengths are meters; joint angles are radians.
Metric definitions, source frames and object-surface sampling are in the JSON.
